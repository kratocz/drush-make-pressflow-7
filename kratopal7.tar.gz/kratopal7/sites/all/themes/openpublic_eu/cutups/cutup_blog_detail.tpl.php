<div id="content" class="clearfix">
          <div id="main">
            <div id="breadcrumb">
            <ul>
              <li><a href="home.html">Home</a> /</li>

              <li><a href="#">Media Room</a> /</li>

              <li class="active">Blog</li>
            </ul><img class="soc-media" alt="this is a description" src="http://lschoppa.dev.openpublicapp.com/profiles/openpublic/themes/openpublic_theme/img/soc-media.gif"/></div><!--/breadcrumb-->

            <div class="date-tag">
              <span class="date">Posted by Bob Billingsworth on October 6, 2010 at 5:14 PM EDT</span>

            </div>

            <h1 id="page-title">Blog Posting about Posting Blogs in the 21st Century and Beyond</h1>

            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>

            <table class="photo-with-caption photo-with-caption-nowrap">
              <caption align="bottom">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt
              </caption>

              <tbody>
                <tr>
                  <td><img src="http://lschoppa.dev.openpublicapp.com/profiles/openpublic/themes/openpublic_theme/img/photo500x333.jpg" alt="this is a description" /></td>
                </tr>
              </tbody>
            </table>

            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in <a href="#">voluptate velit</a> esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in <a href="#">voluptate velit</a> esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

            <h3>This is an H3</h3>

            <p>sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in <a href="#">voluptate velit</a> esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

            <ul>
              <li>This is a list item</li>

              <li>Aliquip ex ea commodo <a href="#">consequat</a></li>
            </ul>

            <h4>This is an H4</h4>

            <ol>
              <li>This is an ordered list item</li>

              <li>Aliquip ex ea commodo <a href="#">consequat</a></li>
            </ol>

            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in <a href="#">voluptate velit</a> esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in <a href="#">voluptate velit</a> esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

            
             <table class="photo-with-caption photo-with-caption-right">
              <caption align="bottom">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt
              </caption>

              <tbody>
                <tr>
                  <td><img src="http://lschoppa.dev.openpublicapp.com/profiles/openpublic/themes/openpublic_theme/img/photo250x150.jpg" alt="this is a description" /></td>
                </tr>
              </tbody>

            </table>
            
                 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in <a href="#">voluptate velit</a> esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in <a href="#">voluptate velit</a> esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
          
     
          <ul id="related-terms">
            <li class="section-title">Related Terms:</li>
            <li><a href="#">Macenas</a>, </li>

            <li><a href="#">term 123</a>, </li>
            <li><a href="#">Mollit</a>, </li>
            <li><a href="#">Fugiat</a>, </li>
            <li><a href="#">term 14555</a>, </li>
            <li><a href="#">Laboram</a>, </li>

          
          </ul><!--related terms-->
          
          <div id="comments">
          
          <div class="header clearfix">
            <h3>Comments</h3>
            <div class="login-to-comment"><a href="#">Login</a> to post comments</div>
          </div><!--/header-->
          
          <div class="comment-entry">

          <div class="author">Samantha Warren:</div><!--/author-->
          <div class="comment">
            <p>unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur.</p>
          
          </div><!--/comment-->
          
          <div class="post-date-reply clearfix">
            <div class="post-date">October 11, 2010 </div><a class="like" href="#"><img alt="this is a description" src="http://lschoppa.dev.openpublicapp.com/profiles/openpublic/themes/openpublic_theme/img/icons/icon-fb-like.gif" /></a>
             <a class="reply" href="#">Reply</a>

          </div><!--/post date reply-->
          
          </div><!--/comment-entry-->
          
          
             <div class="comment-entry indented">
          <div class="author">JoBob Baker:</div><!--/author-->
          <div class="comment">
            <p>unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi.</p>
          
          </div><!--/comment-->
          
        <div class="post-date-reply clearfix">
            <div class="post-date">October 11, 2010 </div><a class="like" href="#"><img alt="this is a description" src="http://lschoppa.dev.openpublicapp.com/profiles/openpublic/themes/openpublic_theme/img/icons/icon-fb-like.gif" /></a>
             <a class="reply" href="#">Reply</a>

          </div><!--/post date reply-->
          
          </div><!--/comment-entry-->
          
          </div><!--/comments-->
          

          
          
          
          
          
          
          </div><!--/main-->

          <div id="right-rail">

            <div id="right-nav" class="section-content clearfix">
              <h3>Media Room</h3>

              <ul>
                <li><a class="active" href="/press-releases">Press Releases</a></li>

                <li class="active"><a href="#">Blog</a></li>
              </ul>

            </div>

            <div class="section-content" id="related-section">
              <h3>Related Content</h3>

              <div class="entry">
                <div class="date-tag">
                  Posted by John Doe on Oct 11, 2010
                </div><!--/date tag-->

                <h4><a href="#">This is a short blog title.</a></h4>

                <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque.</p>
              </div><!--/entry-->

              <div class="divide"></div>

              <div class="entry">
                <div class="date-tag">

                  Posted by John Doe on Oct 11, 2010
                </div><!--/date tag-->

                <h4><a href="#">This is a long, long, long, long, long, long, long, blog title.</a></h4>

                <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque.</p>
              </div><!--/entry-->

              <div class="divide"></div>

              <div class="read-more">
                <a href="#">More Blog Posts</a>
              </div><!--/read more-->
            </div><!--/section content-->

            <div class="section-content clearfix connect-block" id="stay-connected">
              <h3>Stay Connected</h3>

              <ul class="clearfix">

                <li class="twitter"><a href="#">twitter</a></li>

                <li class="fb"><a href="#">facebook</a></li>

                <li class="youtube"><a href="#">youtube</a></li>

                <li class="linkedin"><a href="#">linkedin</a></li>
              </ul>

            </div><!--/section content-->
          </div><!--/right rail-->
        </div><!--/content-->

