       <div id="content" class="clearfix">
          <div id="main">
            <div id="breadcrumb">
            <ul>
              <li><a href="home.html">Home</a> /</li>

              <li class="active">Search Results</li>
            </ul><img class="soc-media" alt="this is a description" src="images/soc-media.gif" /></div><!--/breadcrumb-->

            <div id="search-box">
              <div id="search-box-inner">
                <h3>Search: <span class="search-term">Test Term</span></h3>

                <form>

                  <input type="text" class="form-text" value="test term" size="15" id="edit-search-form-1" name="#" maxlength="128" /> <input type="submit" class="form-submit" value="Search" id="search" />
                </form>
              </div><!--/search-box-inner-->
            </div><!--/search-box-->
            
            <div class="search-results-number">Current search found 3,714 items for test term</div>
            
            <ul class="search-sort-results clearfix">
              <li class="sort-label">Sort by:</li>

              <li><a href="#">Relevancy</a>  |</li>
                   <li><a href="#">Title</a>  |</li>
                <li><a href="#">Type</a>  |</li>
                 <li><a href="#">Author</a>  |</li>

                  <li><a href="#">Date</a></li>
            
            
            </ul>
                      
            
            <div class="entry">
              <div class="date-tag">
                <span class="date">Posted by John Doe on Oct 11, 2010</span> | <span class="tag"><a href="#">Press Release</a></span>
              </div><!--/date tag-->

              <h4><a href="#">Moran, Connolly, Warner Penn Letter to Defense Secretary on BRAC Needs</a></h4>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div><!--/entry-->

            <div class="divide"></div>
            
                   <div class="entry">
              <div class="date-tag">

                <span class="date">Posted by John Doe on Oct 11, 2010</span> | <span class="tag"><a href="#">Press Release</a></span>
              </div><!--/date tag-->

              <h4><a href="#">Moran, Connolly, Warner Penn Letter to Defense Secretary on BRAC Needs</a></h4>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div><!--/entry-->

            
                  <div class="divide"></div>
            
                   <div class="entry">
              <div class="date-tag">
                <span class="date">Posted by John Doe on Oct 11, 2010</span> | <span class="tag"><a href="#">Press Release</a></span>
              </div><!--/date tag-->

              <h4><a href="#">Moran, Connolly, Warner Penn Letter to Defense Secretary on BRAC Needs</a></h4>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div><!--/entry-->
            
                  <div class="divide"></div>
            
                   <div class="entry">
              <div class="date-tag">
                <span class="date">Posted by John Doe on Oct 11, 2010</span> | <span class="tag"><a href="#">Press Release</a></span>

              </div><!--/date tag-->

              <h4><a href="#">Moran, Connolly, Warner Penn Letter to Defense Secretary on BRAC Needs</a></h4>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div><!--/entry-->
            
                  <div class="divide"></div>
            
                   <div class="entry">
              <div class="date-tag">

                <span class="date">Posted by John Doe on Oct 11, 2010</span> | <span class="tag"><a href="#">Press Release</a></span>
              </div><!--/date tag-->

              <h4><a href="#">Moran, Connolly, Warner Penn Letter to Defense Secretary on BRAC Needs</a></h4>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div><!--/entry-->

            
                  <div class="divide"></div>
            
                   <div class="entry">
              <div class="date-tag">
                <span class="date">Posted by John Doe on Oct 11, 2010</span> | <span class="tag"><a href="#">Press Release</a></span>
              </div><!--/date tag-->

              <h4><a href="#">Moran, Connolly, Warner Penn Letter to Defense Secretary on BRAC Needs</a></h4>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div><!--/entry-->
            
            <div class="divide"></div>

            <div class="clearfix" id="paging">
              <ul class="clearfix">
                <li class="previous"><a href="#">« Previous</a></li>

                <li><a href="#">1</a></li>

                <li><a href="#">2</a></li>

                <li class="active"><a href="#">3</a></li>

                <li><a href="#">4</a></li>

                <li class="next"><a href="#">Next »</a></li>

              </ul>
            </div>
          </div><!--/main-->

          <div id="right-rail">
            <div class="section-content" id="narrow-search-results">
              <h3>Narrow Your Search Results</h3>

                            <div class="filter-choices">

                  <ul>
                    <li><strong>Filter by Post Date</strong></li>

                    <li><a href="#">2010 (3,014)</a></li>

                    <li><a href="#">2009 (699)</a></li>

                    <li><a href="#">2008 or earlier (1)</a></li>

                  </ul>

                  <ul>
                    <li><strong>Filter by Type</strong></li>

                    <li><a href="#">Article (3,014)</a></li>

                    <li><a href="#">Blog (699)</a></li>

                    <li><a href="#">Service (1)</a></li>
                  </ul>

                  <ul>
                    <li><strong>Filter by Issue</strong></li>

                    <li><a href="#">Airport Security (2,400)</a></li>

                    <li><a href="#">Baseball (353)</a></li>

                    <li><a href="#">China (25)</a></li>
                     <li><a href="#">Dolphins in Daner (1)</a></li>
                  </ul>
                </div><!--/filter choices-->

                        
            </div><!--/section content-->
          </div><!--/right rail-->
        </div><!--/content-->
