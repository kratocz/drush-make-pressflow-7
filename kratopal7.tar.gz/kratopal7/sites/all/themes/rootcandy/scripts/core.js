/*
 * Create a namespace for all admincandy scripting stuff.
 *
 */
var AdminCandy = {};
