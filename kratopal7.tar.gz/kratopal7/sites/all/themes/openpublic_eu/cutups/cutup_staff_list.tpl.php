<div id="content" class="clearfix">
          <div id="main">
            <div id="breadcrumb">
            <ul>
              <li><a href="home.html">Home</a> /</li>

              <li><a href="#">About</a> /</li>

              <li class="active">Staff Directory</li>
            </ul><img class="soc-media" alt="this is a description" src="http://lschoppa.dev.openpublicapp.com/profiles/openpublic/themes/openpublic_theme/img/soc-media.gif" /></div><!--/breadcrumb-->

            <h1 id="page-title">Staff Directory</h1>

            <div class="divide-double-line"></div>

            <div class="entry list-item staff-list clearfix">
              <div class="staff-photo"><img alt="this is a description" src="http://lschoppa.dev.openpublicapp.com/profiles/openpublic/themes/openpublic_theme/img/photo95x95-brad.jpg" /></div>

              <h4><a href="#">Johnson, Brad</a></h4>

              <p class="staff-position">Director of Finance</p>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>

            </div><!--/entry-->

            <div class="entry list-item staff-list clearfix exec">
              <div class="staff-photo"><img alt="this is a description" src="http://lschoppa.dev.openpublicapp.com/profiles/openpublic/themes/openpublic_theme/img/photo95x95-tiffany.jpg" /></div>

              <div class="staff-info">
                <a href="#"><img alt="this is a description" class="icon-exec" src="http://lschoppa.dev.openpublicapp.com/profiles/openpublic/themes/openpublic_theme/img/icons/icon-exec.png" /></a>

                <h4><a href="#">Baker, Tiffany</a></h4>

                <p class="staff-position">Deputy Administrative Director of Logistics</p>

                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
              </div><!--/staff info-->
            </div><!--/entry-->

            <div class="entry list-item staff-list clearfix">
              <div class="staff-photo"><img alt="this is a description" src="http://lschoppa.dev.openpublicapp.com/profiles/openpublic/themes/openpublic_theme/img/photo95x95-josh.jpg" /></div>

              <h4><a href="#">Simpson, Scott COL</a></h4>

              <p class="staff-position">Interior Minister of Graphic Design</p>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div><!--/entry-->

            <div class="entry list-item staff-list clearfix">
              <div class="staff-photo"><img alt="this is a description" src="http://lschoppa.dev.openpublicapp.com/profiles/openpublic/themes/openpublic_theme/img/photo95x95-blank.jpg" /></div>

              <h4><a href="#">Lee, Sheila May</a></h4>

              <p class="staff-position">Finance Consultant</p>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div><!--/entry-->


 <div class="entry list-item staff-list clearfix">

              <div class="staff-photo"><img alt="this is a description" src="http://lschoppa.dev.openpublicapp.com/profiles/openpublic/themes/openpublic_theme/img/photo95x95-brad.jpg" /></div>

              <h4><a href="#">Johnson, Brad</a></h4>

              <p class="staff-position">Director of Finance</p>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div><!--/entry-->

            <div class="entry list-item staff-list clearfix exec">
              <div class="staff-photo"><img alt="this is a description" src="http://lschoppa.dev.openpublicapp.com/profiles/openpublic/themes/openpublic_theme/img/photo95x95-tiffany.jpg" /></div>

              <div class="staff-info">
                <a href="#"><img alt="this is a description" class="icon-exec" src="http://lschoppa.dev.openpublicapp.com/profiles/openpublic/themes/openpublic_theme/img/icons/icon-exec.png" /></a>

                <h4><a href="#">Baker, Tiffany</a></h4>

                <p class="staff-position">Deputy Administrative Director of Logistics</p>

                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
              </div><!--/staff info-->
            </div><!--/entry-->

            <div class="entry list-item staff-list clearfix">
              <div class="staff-photo"><img alt="this is a description" src="http://lschoppa.dev.openpublicapp.com/profiles/openpublic/themes/openpublic_theme/img/photo95x95-josh.jpg" /></div>

              <h4><a href="#">Simpson, Scott COL</a></h4>

              <p class="staff-position">Interior Minister of Graphic Design</p>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div><!--/entry-->

            <div class="entry list-item staff-list clearfix">
              <div class="staff-photo"><img alt="this is a description" src="http://lschoppa.dev.openpublicapp.com/profiles/openpublic/themes/openpublic_theme/img/photo95x95-blank.jpg" /></div>

              <h4><a href="#">Lee, Sheila May</a></h4>

              <p class="staff-position">Finance Consultant</p>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div><!--/entry-->



            <div class="clearfix" id="paging">
              <ul class="clearfix">

                <li class="previous"><a href="#">« Previous</a></li>

                <li><a href="#">1</a></li>

                <li><a href="#">2</a></li>

                <li class="active"><a href="#">3</a></li>

                <li><a href="#">4</a></li>

                <li class="next"><a href="#">Next »</a></li>
              </ul>
            </div>
          </div><!--/main-->

          <div id="right-rail">
            <div id="right-nav" class="section-content clearfix">
              <h3>About</h3>

              <ul>
                <li><a href="#">Leadership</a></li>

                <li class="active"><a class="active" href="/press-releases">Staff Directory</a></li>

                <li><a href="#">Contact Us</a></li>
              </ul>
            </div><!--/right nav-->

            <div class="section-content" id="blog-section">
              <h3>Latest From Our Blog</h3>

              <div class="entry">
                <div class="date-tag">
                  Posted by John Doe on Oct 11, 2010
                </div><!--/date tag-->

                <h4><a href="#">This is a short blog title.</a></h4>

                <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque.</p>
              </div><!--/entry-->

              <div class="divide"></div>

              <div class="entry">
                <div class="date-tag">
                  Posted by John Doe on Oct 11, 2010
                </div><!--/date tag-->

                <h4><a href="#">This is a long, long, long, long, long, long, long, blog title.</a></h4>

                <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque.</p>
              </div><!--/entry-->

              <div class="divide"></div>

              <div class="read-more">
                <a href="#">More Blog Posts</a>

              </div><!--/read more-->
            </div><!--/section content-->

            <div class="section-content clearfix connect-block" id="stay-connected">
              <h3>Stay Connected</h3>

              <ul class="clearfix">
                <li class="twitter"><a href="#">twitter</a></li>

                <li class="fb"><a href="#">facebook</a></li>

                <li class="youtube"><a href="#">youtube</a></li>

                <li class="linkedin"><a href="#">linkedin</a></li>
              </ul>
            </div><!--/section content-->
          </div><!--/right rail-->

        </div><!--/content-->
