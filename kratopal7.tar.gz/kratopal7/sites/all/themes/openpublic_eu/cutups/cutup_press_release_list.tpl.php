       <div id="content" class="clearfix">
          <div id="main">
          
                    <div id="breadcrumb">
            <ul>
              <li><a href="home.html">Home</a> /</li>

              <li><a href="#">Media Room</a> /</li>

              <li class="active">Press Releases</li>
            </ul><img class="soc-media" alt="this is a description" src="http://lschoppa.dev.openpublicapp.com/profiles/openpublic/themes/openpublic_theme/img/soc-media.gif"/></div><!--/breadcrumb-->
          
            <h1 id="page-title">Press Releases</h1>

            <div class="divide-double-line"></div>

            <div class="entry">
              <div class="date-tag">
                <span class="date">Oct 11, 2010</span> | <span class="tag"><a href="#">Press Release</a></span>
              </div><!--/date tag-->

              <h4><a href="#">Excepteur sint occaecat cupidatat non proident</a></h4>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div><!--/entry-->

            <div class="divide"></div>

            <div class="entry">
              <div class="date-tag">
                <span class="date">Oct 11, 2010</span> | <span class="tag"><a href="#">Press Release</a></span>

              </div><!--/date tag-->

              <h4><a href="#">Moran, Connolly, Warner Penn Letter to Defense Secretary on BRAC Needs</a></h4>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div><!--/entry-->

            <div class="divide"></div>

            <div class="entry">

              <div class="date-tag">
                <span class="date">Oct 11, 2010</span> | <span class="tag"><a href="#">Press Release</a></span>
              </div><!--/date tag-->

              <h4><a href="#">Moran, Connolly, Warner Penn Letter to Defense Secretary on BRAC Needs</a></h4>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>

            </div><!--/entry-->

            <div class="divide"></div>

            <div class="entry">
              <div class="date-tag">
                <span class="date">Oct 11, 2010</span> | <span class="tag"><a href="#">Press Release</a></span>
              </div><!--/date tag-->

              <h4><a href="#">Excepteur sint occaecat cupidatat non proident</a></h4>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div><!--/entry-->

            <div class="divide"></div>

            <div class="entry">
              <div class="date-tag">

                <span class="date">Oct 11, 2010</span> | <span class="tag"><a href="#">Press Release</a></span>
              </div><!--/date tag-->

              <h4><a href="#">Excepteur sint occaecat cupidatat non proident</a></h4>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div><!--/entry-->

            <div class="divide"></div>

            <div class="entry">
              <div class="date-tag">
                <span class="date">Oct 11, 2010</span> | <span class="tag"><a href="#">Press Release</a></span>
              </div><!--/date tag-->

              <h4><a href="#">Moran, Connolly, Warner Penn Letter to Defense Secretary on BRAC Needs</a></h4>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div><!--/entry-->

            <div class="divide"></div>

            <div class="entry">
              <div class="date-tag">

                <span class="date">Oct 11, 2010</span> | <span class="tag"><a href="#">Press Release</a></span>
              </div><!--/date tag-->

              <h4><a href="#">Moran, Connolly, Warner Penn Letter to Defense Secretary on BRAC Needs</a></h4>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
            </div><!--/entry-->

            <div class="divide"></div>

            <div class="clearfix" id="paging">
              <ul class="clearfix">
                <li class="previous"><a href="#">« Previous</a></li>

                <li><a href="#">1</a></li>

                <li><a href="#">2</a></li>

                <li class="active"><a href="#">3</a></li>

                <li><a href="#">4</a></li>

                <li class="next"><a href="#">Next »</a></li>
              </ul>
            </div>
          </div><!--/main-->

          <div id="right-rail">
            <div id="right-nav" class="section-content clearfix">
              <h3>Media Room</h3>

              <ul>
                <li class="active"><a class="active" href="/press-releases">Press Releases</a></li>

                <li><a href="#">Blog</a></li>

              </ul>
            </div><!--/right nav-->
            
          <div class="section-content right-list" id="category-nav">
              <h3>Categories</h3>
               <ul>
                <li><a href="#">Defense</a></li>
                <li><a href="#">Education</a></li>

                <li><a href="#">Energy</a></li>
                       
               </ul>
           
           
                       </div><!--/section content-->

            
            
            

            <div class="section-content" id="blog-section">
              <h3>Latest From Our Blog</h3>

              <div class="entry">
                <div class="date-tag">

                  Posted by John Doe on Oct 11, 2010
                </div><!--/date tag-->

                <h4><a href="#">This is a short blog title.</a></h4>

                <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque.</p>
              </div><!--/entry-->

              <div class="divide"></div>

              <div class="entry">
                <div class="date-tag">
                  Posted by John Doe on Oct 11, 2010
                </div><!--/date tag-->

                <h4><a href="#">This is a long, long, long, long, long, long, long, blog title.</a></h4>

                <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque.</p>
              </div><!--/entry-->

              <div class="divide"></div>

              <div class="read-more">
                <a href="#">More Blog Posts</a>
              </div><!--/read more-->
            </div><!--/section content-->

            <div class="section-content clearfix connect-block" id="stay-connected">
              <h3>Stay Connected</h3>

              <ul class="clearfix">
                <li class="twitter"><a href="#">twitter</a></li>

                <li class="fb"><a href="#">facebook</a></li>

                <li class="youtube"><a href="#">youtube</a></li>

                <li class="linkedin"><a href="#">linkedin</a></li>

              </ul>
            </div><!--/section content-->
          </div><!--/right rail-->
        </div><!--/content-->
