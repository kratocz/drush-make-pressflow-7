
ABOUT
-----

This is a base theme designed for the Panels Everywhere module. It builds upon
a grid framework similar to the 960.gs project. The biggest difference is that
this grid system is more fine grained with 48 to 65 columns. Each column is
10 pixels wide with 10 pixels gutter. The default 48 column version is 960
pixels wide, the 49 column version is 980 pixels wide, the 50 column version is
1000 pixels wide and the 65 column version is 1300 pixels wide.


USAGE
-----

It's important that you use the layout "Precision site template", as the
layout for the panel "Site template". If your site doesn't center properly,
you've probably missed this.
