
            <div id="breadcrumb">
            <ul>
              <li><a href="home.html">Home</a> /</li>

              <li><a href="#">Media Room</a> /</li>
              <li><a href="#">Press Releases</a> /</li>

              <li class="active">ABC Agency Supports Reform</li>
            </ul><img class="soc-media" alt="this is a description" src="http://lschoppa.dev.openpublicapp.com/profiles/openpublic/themes/openpublic_theme/img/soc-media.gif"/></div><!--/breadcrumb-->

           
            <h1 id="page-title">ABC Agency Supports Reform</h1>
            <div class="date-tag">October 6, 2010  | Categories: <a href="#">Education,</a> <a href="Reform Efforts">Reform Efforts</a></div>


  <table class="photo-with-caption photo-with-caption-left">
              <caption align="bottom">
                This is the main image caption.
              </caption>

              <tbody>
                <tr>
                  <td><img src="http://lschoppa.dev.openpublicapp.com/profiles/openpublic/themes/openpublic_theme/img/photo250x150.jpg" alt="this is a description" /></td>
                </tr>
              </tbody>
            </table>
            
         

            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>

                   <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in <a href="#">voluptate velit</a> esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in <a href="#">voluptate velit</a> esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

                            <img src="http://lschoppa.dev.openpublicapp.com/profiles/openpublic/themes/openpublic_theme/img/photo250x150.jpg" class="photo photo-left" alt="this is a description" />         
                 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in <a href="#">voluptate velit</a> esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in <a href="#">voluptate velit</a> esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

          
     
          <ul id="related-terms">
            <li class="section-title">Related Terms:</li>
            <li><a href="#">Macenas</a>, </li>
            <li><a href="#">term 123</a>, </li>
            <li><a href="#">Mollit</a>, </li>

            <li><a href="#">Fugiat</a>, </li>
            <li><a href="#">term 14555</a>, </li>
            <li><a href="#">Laboram</a>, </li>
          
          </ul><!--related terms-->
          
         
          
          
          
          
          
          
      