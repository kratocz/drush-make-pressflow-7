       <div id="content" class="clearfix">
          <div id="main">
            <div id="breadcrumb">
            <ul>
              <li><a href="home.html">Home</a> /</li>

              <li><a href="#">Media Room</a> /</li>

              <li class="active">Blog</li>
            </ul><img class="soc-media" alt="this is a description" src="http://lschoppa.dev.openpublicapp.com/profiles/openpublic/themes/openpublic_theme/img/soc-media.gif" /></div><!--/breadcrumb-->

            <h1 id="page-title">Blog</h1>

            <div class="divide-double-line"></div>

            <div class="entry list-item-blog first-item-blog">
              <div class="date-tag">
                <span class="date">Posted by Jake Holder on Oct 11, 2010</span>
              </div><!--/date tag-->

              <h4><a href="blog-detail.html">Blog Posting about Posting Blogs in the 21st Century and Beyond</a></h4>

              <table class="photo-with-caption photo-with-caption-nowrap">
                <caption align="bottom">
                  Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt
                </caption>

                <tbody>
                  <tr>
                    <td><img src="http://lschoppa.dev.openpublicapp.com/profiles/openpublic/themes/openpublic_theme/img/photo500x333.jpg" alt="this is a description" /></td>
                  </tr>
                </tbody>

              </table>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>

              <div class="read-more">
                <a href="#">Read full blog post</a>
              </div><!--/read more-->

            </div><!--/entry-->

            <div class="divide"></div>

            <div class="entry list-item-blog">
              <div class="date-tag">
                <span class="date">Posted by Jake Holder on Oct 11, 2010</span>
              </div><!--/date tag-->

              <h4><a href="blog-detail.html">This is another blog post</a></h4>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>

              <div class="read-more">
                <a href="#">Read full blog post</a>
              </div><!--/read more-->
            </div><!--/entry-->

            <div class="divide"></div>

            <div class="entry list-item-blog">
              <div class="date-tag">
                <span class="date">Posted by Jake Holder on Oct 11, 2010</span>
              </div><!--/date tag-->

              <h4><a href="blog-detail.html">This is another blog post</a></h4>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

           <img src="http://lschoppa.dev.openpublicapp.com/profiles/openpublic/themes/openpublic_theme/img/photo450x315.jpg" class="photo-nowrap" alt="this is a description" />
            

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>

              <div class="read-more">
                <a href="#">Read full blog post</a>
              </div><!--/read more-->

            </div><!--/entry-->

            <div class="divide"></div>

            <div class="entry list-item-blog">
              <div class="date-tag">
                <span class="date">Posted by Jake Holder on Oct 11, 2010</span>
              </div><!--/date tag-->

              <h4><a href="blog-detail.html">This is another blog post</a></h4>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>

              <div class="read-more">
                <a href="#">Read full blog post</a>
              </div><!--/read more-->
            </div><!--/entry-->

            <div class="divide"></div>

            <div class="clearfix" id="paging">
              <ul class="clearfix">
                <li class="previous"><a href="#">« Previous</a></li>

                <li><a href="#">1</a></li>

                <li><a href="#">2</a></li>

                <li class="active"><a href="#">3</a></li>

                <li><a href="#">4</a></li>

                <li class="next"><a href="#">Next »</a></li>
              </ul>
            </div>
          </div><!--/main-->

          <div id="right-rail">
            <div id="right-nav" class="section-content clearfix">
              <h3>Media Room</h3>

              <ul>
                <li><a class="active" href="#">Press Releases</a></li>

                <li class="active"><a href="#">Blog</a></li>

              </ul>
            </div><!--/right nav-->

            <div id="most-popular">
              <div class="tabs-nav clearfix">
                <ul>
                  <li id="most-views" class="active"><a href="#">Most Views</a></li>

                  <li id="most-comments"><a href="#">Most Comments</a></li>

                </ul>
              </div><!--/tabs nav-->

              <div class="clear ui-tabs-panel">
                <ul class="right-list">
                  <li><a href="#">This is a blog post</a></li>

                  <li><a href="#">This is a really popular blog post</a></li>

                  <li><a href="#">This is another blog post that got a lot of views</a></li>

                  <li><a href="#">This is a blog post</a></li>

                  <li><a href="#">This is a blog post</a></li>
                </ul>
              </div><!--/ui tabs panel-->
            </div><!--/most popular-->

            <div class="section-content right-list" id="category-nav">
              <h3>Categories</h3>

              <ul>
                <li><a href="#">Defense</a></li>

                <li><a href="#">Education</a></li>

                <li><a href="#">Energy</a></li>
              </ul>
            </div><!--/section content-->

            <div class="section-content right-list" id="archive-nav">
              <h3>Archives</h3>

              <ul>
                <li><a href="#">January 2010</a></li>

                <li><a href="#">February 2010</a></li>

                <li><a href="#">March 2010</a></li>
              </ul>
            </div><!--/section content-->
          </div><!--/right rail-->
        </div><!--/content-->
