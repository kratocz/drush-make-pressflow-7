
  Internet Explorer Overrides

  Adaptivetheme includes special conditional classes on the HTML element
  which allow you to easily target styles at specific version of IE.

  These are the classes you can use:

  .iem7  - IE7 Mobile
  .ie6   - IE6
  .ie6-7 - IE6/7
  .ie6-8 - IE6/7/8
  .ie7   - IE7
  .ie8   - IE8

  If you prefer to use IE conditional stylesheets please see template.php - we
  have included a very simple method of loading conditional stylesheets, read more
  about this in our online docs:

  http://adaptivethemes.com/documentation/working-with-internet-explorer

