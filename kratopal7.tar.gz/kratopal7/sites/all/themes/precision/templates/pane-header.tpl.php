<?php if (!empty($logo)): ?>
  <a class="site-title" href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>" rel="home">
    <img class="site-logo" src="<?php print $logo; ?>" alt="<?php print $site_name; ?>" />
  </a>
<?php endif; ?>
