<?php if (!empty($primary_links)) print theme('links', $primary_links, array('class' => 'links links-primary clear-block')); ?>
