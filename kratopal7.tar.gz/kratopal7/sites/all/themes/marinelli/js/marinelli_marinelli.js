/**
 * common theme behaviours
 * 
 */
 
jQuery(document).ready(function($){
	$("*").removeClass("marinelli-hide-no-js"); // remove the hide class (see common.css)
});