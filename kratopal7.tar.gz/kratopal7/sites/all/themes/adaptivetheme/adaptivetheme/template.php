<?php

/**
 * IMPORTANT WARNING: DO NOT MODIFY THIS FILE OR ANY OF THE INCLUDED FILES.
 */

include_once(drupal_get_path('theme', 'adaptivetheme') . '/inc/google.web.fonts.inc');
include_once(drupal_get_path('theme', 'adaptivetheme') . '/inc/template.helpers.inc');
include_once(drupal_get_path('theme', 'adaptivetheme') . '/inc/template.theme.inc');
include_once(drupal_get_path('theme', 'adaptivetheme') . '/inc/template.process.inc');
include_once(drupal_get_path('theme', 'adaptivetheme') . '/inc/template.alter.inc');
